Here is the link of all output files I have, some models and figures:) 

https://drive.google.com/file/d/1jIrL4CE4a449D5M3bJj7rPLyWM70ejQF/view?usp=sharing



